# Insider Flow Analyzer Bot

Fetches daily insider trading data and sends a summary to Telegram.